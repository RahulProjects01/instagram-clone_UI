export const SIGN_UP = "SIGN-UP";
export const SIGN_IN = "SIGN_IN";



