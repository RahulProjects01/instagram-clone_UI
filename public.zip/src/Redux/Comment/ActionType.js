// ActionType.js
export const CREATE_COMMENT = "CREATE_COMMENT";
export const GET_POST_COMMENT = "GET_POST_COMMENT";
export const LIKE_COMMENT = "LIKE_COMMENT";
export const UNLIKE_COMMENT = "UNLIKE_COMMENT";
