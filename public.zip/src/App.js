import Router from '../src/Pages/Router/Router'

function App() {
  return (
    <div className="App">
      <Router/>
    </div>
  );
}

export default App;
